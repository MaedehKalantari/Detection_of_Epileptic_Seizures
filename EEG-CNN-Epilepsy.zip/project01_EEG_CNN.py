import torch
from torch.utils.data import DataLoader
from EEG_dataset_module import CustomDataset,ToTensor,Filter
import torch.nn as nn
from torchvision.transforms import Compose
# import matplotlib.pyplot as plt
from torch import optim
pathname='train'
transfrom= Compose((Filter(Fs=173.61,fl=8,fh=15,order=3,type='bandpass'),ToTensor()))
ds_train= CustomDataset(pathname,transfrom)

pathname='test'
transfrom= Compose((Filter(Fs=173.61,fl=8,fh=15,order=3,type='bandpass'),ToTensor()))
ds_test= CustomDataset(pathname,transfrom)

train_loader= DataLoader(ds_train,batch_size=32,
                         drop_last=False,shuffle=True,num_workers=0)

test_loader= DataLoader(ds_test,batch_size=32,
                         drop_last=False,shuffle=False,num_workers=0)

class ConvNet(nn.Module):
    def __init__(self):
        super(ConvNet,self).__init__()
        self.conv1= nn.Conv1d(in_channels=1, out_channels=15, kernel_size=5,padding=2)
        self.pool1= nn.MaxPool1d(4)
        self.conv2= nn.Conv1d(in_channels=15, out_channels=20, kernel_size=5,padding=2)
        self.pool2= nn.MaxPool1d(4)
        
        self.fc1= nn.Linear(20*256, 200)
        self.fc2= nn.Linear(200, 84)
        self.fc3= nn.Linear(84, 50)
        self.fc4= nn.Linear(50, 3)
        self.tanh= nn.Tanh()
    def forward(self,x):
        out=  self.tanh(self.conv1(x))
        out=  self.pool1(out)
        out=  self.tanh(self.conv2(out))
        out=  self.pool2(out)
        
        features= out.flatten(start_dim=1)
        out= self.tanh(self.fc1(features))
        out= self.tanh(self.fc2(out))
        out= self.tanh(self.fc3(out))
        out= (self.fc4(out))
        return out,features
   
#%% define hyperparameters
epoch=80 # number of training iteration
# batch_size= 256 # the number of batch size is determind by the user, it helps training be easy and calculation fast
lr=0.001 # the value of learning rate is determined by the user,
model= ConvNet()
#%% import MNIST dataset
optimizer= optim.SGD(params=model.parameters(),lr=0.01)
# optimizer= optim.SGD(params=model.parameters(),lr=lr,momentum=0.2)
# optimizer= optim.Adam(params=model.parameters(),lr=lr,betas=(0.9,0.999),eps= 1e-8)
# optimizer= optim.RMSprop(params=model.parameters(),lr=lr)
criteria= nn.CrossEntropyLoss()
 #%% train Neural Network
mse=[]
elapsed=[]
for iter in range(1,epoch):
     er=[]
     for i,(xbatch,ybatch) in enumerate(train_loader):
          # farward pass
          xbatch= xbatch.unsqueeze(1)
          # xbatch= xbatch.unsqueeze(1)
          ypred,_= model(xbatch)
          # backward pass 
          loss=  criteria(ypred,ybatch)
          loss.backward() # triger gradient calculation
          optimizer.step()# update parameters(synaptic wieghts)
          optimizer.zero_grad() # clear gradients

          er.append(loss.detach())
          # print(i,er[i])
          
     loss= torch.mean(torch.tensor(er))
     mse.append(loss)
     # tt= torch.mean(torch.tensor(elapsed))
     print(f'MSE({iter-1}): {mse[iter-1]:.5f}')

mse=torch.tensor(mse)
# print(f'Averaged elapased time: {torch.mean(torch.tensor(elapsed)):.5f}')
#%% test trained Neural Network

with torch.no_grad():
    n_sample=0
    n_correct=0
    for i,(samples,labels) in enumerate(test_loader):
        # forward pass
        samples= samples.unsqueeze(1)
        y_hat,_= model(samples)
        y_hat= torch.argmax(y_hat,dim=1)
        n_correct+=  torch.sum(y_hat==labels)
        n_sample+=labels.size(0)

accuracy= n_correct/n_sample *100
print('Accuracy:',accuracy)
