import torch
from torch.utils.data import Dataset
import glob
import pandas as pd
from scipy import signal 
import numpy as np

class CustomDataset(Dataset):
    def __init__(self,pathname,transform=None,target_transform=None):
        self.file_names= glob.glob(pathname+ '\*\*.txt')
        self.class_map= {'S':0,'Z':1,'F':2}
        self.transform= transform
        self.target_transform= target_transform
        
    def __len__(self):
        return len(self.file_names)
    
    def __getitem__(self,indx):
        filename= self.file_names[indx]
        df= pd.read_csv(filename,header=None)
        chr= filename.split('\\')[-1][0]
        
        sample= df.iloc[:,0].to_numpy()
        label= self.class_map[chr]
        if self.transform:
            sample= self.transform(sample)
        if self.target_transform:
            label= self.target_transform(label)   
        return sample,label

class ToTensor:
    def __call__(self, sample):
        # sample = torch.from_numpy(sample).type(torch.float32)
        sample = torch.tensor(sample.copy(),dtype=torch.float32)
        return sample

class Filter:
    def __init__(self,Fs,order,fl,fh,type):
        self.fs=Fs
        self.wn= np.array([fl,fh])/(Fs/2)
        self.b,self.a= signal.butter(order, self.wn,btype=type)
        
    def __call__(self, sample):
        sample = signal.filtfilt(self.b,self.a,sample)
        return sample

class Normalize:
    def __init__(self,mu,std):
        self.mean= mu
        self.std= std
        
    def __call__(self,sample):
        sample= (sample-self.mean)/self.std
        return sample 